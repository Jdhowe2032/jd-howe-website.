import React from "react";
import ReactDOM from "react-dom/client";
import JDHoweWebsite from "./JDHoweWebsite";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<JDHoweWebsite />);